import plotly.graph_objects as go
import pandas as pd

# df = pd.read_excel('D:/pycharm_project/图表/america(8月).xlsx')  # 导入数据表格
def create_plotly_figure():
# 绘图
    fig = go.Figure(data=go.Choropleth(
        # locations=df['code'],  # 获取各州编号，设置位置
        # z=df['definte'].astype(float),  # 设置填充色数据
        locationmode='USA-states',  # 绘制的地图地区
        colorscale='Reds',  # 设置基础变化颜色
        colorbar_title="确诊人数",
        # hovertext=df['state'],  # 显示州名
    ))
    # 将数据渲染到地图上显示出地图
    fig.update_layout(
        title_text='USA Cities',
        geo_scope='usa'  # 选定美国地图样式
        # scope可选有"world"，"usa"，"europe"，"asia"，"africa"，"north america"，"south america"
    )
    # 保存到网页
    # fig.write_html('templates/map.html')
    return fig
